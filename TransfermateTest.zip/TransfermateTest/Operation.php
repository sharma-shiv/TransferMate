<?php
  try{
    require_once('./Connection.php');

    $books = simplexml_load_file("./Data.xml") or die("Failed to load");

    foreach($books as $book){
      $status_query = "SELECT * FROM authors where name ='".$book->author."'";
      $result = $conn->query($status_query);

      if ($result->num_rows == 0) {
        $status_query = "INSERT into authors (name) VALUES ('".$book->author."')";;
        $result = $conn->query($status_query);
      }

      $status_query = "SELECT * FROM books join authors on books.author_id = authors.id where books.name ='".$book->name."' and authors.name = '".$book->author."'";
      $result = $conn->query($status_query);

      if ($result->num_rows == 0) {
        $status_query = "SELECT * FROM authors where name = '".$book->author."'";
        $result = $conn->query($status_query);

        $author_id = $result->fetch_array();
        $status_query = "INSERT into books (author_id, name) VALUES (".$author_id['id'].",'".$book->name."')";;
        $result = $conn->query($status_query);
      } 
    }

    header('Location: index.php');
  }catch (Exception $e){
    echo 'Something went wrong'; exit;
  }
?>
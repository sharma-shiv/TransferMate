<?php 

// Create MySQL Database connection with PHP project
$conn = mysqli_connect("localhost", "root", "", "library");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>

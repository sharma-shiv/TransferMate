<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
<?php 
error_reporting(0);
require_once('./Connection.php');

$status_query = "SELECT authors.id, authors.name, GROUP_CONCAT(books.name) as book_name FROM authors left join books on authors.id = books.author_id ";

if(isset($_GET['name']) && $_GET['name'] != "")
{
	$status_query .= " where LOWER(authors.name) like '%".strtolower($_GET['name'])."%'";
}
$status_query .= " group by authors.id";

$result = $conn->query($status_query);
?>
<div>
	<form class="form-control float-left">
		<label class="label">Search By Author Name</label>
		<input type="text" class="form-group" name="name" value="<?php echo  (isset($_GET['name']) && $_GET['name']) ? $_GET['name'] : '' ?>" />
		<input type="Submit" class="btn btn-Primary" name="Submit">
		<a href="index.php" class="btn btn-secondary">Reset</a>
	</form>
	<a class="btn btn-info text-right float-right" href="Operation.php">Read Data</a>
</div>
<table class="table table-border"> 
	<tr>
		<th>Author Name</th>
		<th>Books</th>
	</tr>
<?php
if (($result) && $result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
?>	
	<tr>
		<td><?php echo $row['name'] ?></td>
		<td><?php echo $row['book_name'] ?></td>
	</tr>
<?php
  }
} else {
?>
	<tr>
		<td colspan="2" >No Records</td>
	</tr>
<?php
}
?>
</table>